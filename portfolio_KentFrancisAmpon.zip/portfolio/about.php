<?php
$pageTitle = 'About';
include 'includes/header.php';
?>

<section class="section">
    <div class="section-label">// About Me</div>
    <h2 class="section-title">The Person Behind<br>The Code.</h2>
    <div class="section-divider"></div>

    <div class="about-grid">
        <div class="about-avatar-wrap">
            <div class="about-avatar">👨‍💻</div>
            <div class="about-avatar-frame"></div>
        </div>

        <div class="about-info">
            <p>
                Hi! I'm <strong style="color:var(--text-primary)">Kent Francis M. Ampon</strong>, an IT student 
                enrolled in the Professional Track for IT 3 program. I have a growing foundation in 
                server-side web development, database design, and graphic design — combining technical skill with a visual eye.
            </p>
            <p>
                I enjoy building web applications that are both functional and well-designed. Whether it's writing 
                clean PHP logic, modeling a database, or creating a polished UI in Figma, I bring the same 
                attention to detail to every layer of the stack.
            </p>
            <p>
                Outside of coursework, I explore design trends, tinker with web projects, and continuously 
                improve my craft in both development and visual communication.
            </p>

            <table class="info-table">
                <tr><td>Name</td><td>Kent Francis M. Ampon</td></tr>
                <tr><td>Course</td><td>IT9a/L – Professional Track for IT 3</td></tr>
                <tr><td>Focus</td><td>Web Development &amp; Graphic Design</td></tr>
                <tr><td>Stack</td><td>PHP, MySQL, HTML, CSS, JavaScript</td></tr>
                <tr><td>Design</td><td>Figma, Canva, Adobe Photoshop</td></tr>
                <tr><td>Tools</td><td>VS Code, XAMPP, Git, GitHub</td></tr>
                <tr><td>Status</td><td><span class="badge badge-green">Open to Opportunities</span></td></tr>
            </table>

            <div style="margin-top:2rem; display:flex; gap:1rem; flex-wrap:wrap;">
                <a href="projects.php" class="btn btn-primary">View Projects →</a>
                <a href="contact.php" class="btn btn-outline">Contact Me</a>
            </div>
        </div>
    </div>
</section>

<section class="section" style="padding-top:0;">
    <div class="section-label">// Education & Background</div>
    <h2 class="section-title">My Journey</h2>
    <div class="section-divider"></div>

    <div style="display:flex; flex-direction:column; gap:1.25rem; max-width:700px;">
        <div class="card">
            <span class="card-tag">2023 – Present</span>
            <h3 class="card-title">IT Professional Track — College / University</h3>
            <p class="card-desc">
                Pursuing IT9a/L – Professional Track for IT 3, with coursework in server-side programming,
                database management, and dynamic web application development using PHP and MySQL.
            </p>
        </div>
        <div class="card">
            <span class="card-tag">Academic Project</span>
            <h3 class="card-title">Web-Based Portfolio Management System</h3>
            <p class="card-desc">
                Designed and developed a full-stack portfolio management system demonstrating authentication,
                CRUD operations, and database integration as the IT Mini Project requirement.
            </p>
        </div>
        <div class="card">
            <span class="card-tag">Design Practice</span>
            <h3 class="card-title">Graphic Design & Visual Communication</h3>
            <p class="card-desc">
                Developed design skills through academic projects and self-study using Figma, Canva,
                and Adobe Photoshop — producing posters, social media graphics, and UI mockups.
            </p>
        </div>
        <div class="card">
            <span class="card-tag">Self-Study</span>
            <h3 class="card-title">Continuous Learning</h3>
            <p class="card-desc">
                Actively expanding knowledge through online resources, documentation, and hands-on projects.
                Currently exploring Laravel, REST API design, and advanced CSS techniques.
            </p>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
