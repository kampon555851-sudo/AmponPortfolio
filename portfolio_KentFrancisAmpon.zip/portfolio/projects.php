<?php
require_once 'includes/db.php';
$pageTitle = 'Projects';
include 'includes/header.php';

$conn = getConnection();

// Filter by category
$filter = isset($_GET['category']) ? $conn->real_escape_string($_GET['category']) : '';

if ($filter) {
    $result = $conn->query("SELECT * FROM projects WHERE category = '$filter' ORDER BY created_at DESC");
} else {
    $result = $conn->query("SELECT * FROM projects ORDER BY created_at DESC");
}

$projects = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

// Get unique categories
$catResult = $conn->query("SELECT DISTINCT category FROM projects ORDER BY category");
$categories = $catResult ? $catResult->fetch_all(MYSQLI_ASSOC) : [];

$conn->close();
?>

<section class="section">
    <div class="section-label">// My Work</div>
    <h2 class="section-title">Projects</h2>
    <div class="section-divider"></div>

    <!-- Category Filter -->
    <?php if (!empty($categories)): ?>
    <div style="display:flex; gap:0.5rem; flex-wrap:wrap; margin-bottom:2.5rem;">
        <a href="projects.php" class="btn btn-sm <?php echo !$filter ? 'btn-primary' : 'btn-outline'; ?>">All</a>
        <?php foreach ($categories as $cat): ?>
        <a href="projects.php?category=<?php echo urlencode($cat['category']); ?>"
           class="btn btn-sm <?php echo $filter === $cat['category'] ? 'btn-primary' : 'btn-outline'; ?>">
            <?php echo htmlspecialchars($cat['category']); ?>
        </a>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- Projects Grid -->
    <?php if (empty($projects)): ?>
    <div class="empty-state">
        <div class="empty-icon">📁</div>
        <p>No projects found. <a href="admin/projects.php" style="color:var(--accent)">Add a project →</a></p>
    </div>
    <?php else: ?>
    <div class="card-grid">
        <?php foreach ($projects as $p): ?>
        <div class="card">
            <span class="card-tag"><?php echo htmlspecialchars($p['category']); ?></span>
            <h3 class="card-title"><?php echo htmlspecialchars($p['title']); ?></h3>
            <p class="card-desc"><?php echo nl2br(htmlspecialchars($p['description'])); ?></p>
            <?php if ($p['tech_stack']): ?>
            <div style="margin-bottom:1rem; display:flex; flex-wrap:wrap; gap:0.4rem;">
                <?php foreach (explode(',', $p['tech_stack']) as $tech): ?>
                <span style="font-family:var(--mono); font-size:0.65rem; letter-spacing:0.08em; background:var(--accent-dim); color:var(--accent); padding:0.15rem 0.5rem; border-radius:2px;">
                    <?php echo htmlspecialchars(trim($tech)); ?>
                </span>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
            <div class="card-actions">
                <?php if ($p['github_url']): ?>
                <a href="<?php echo htmlspecialchars($p['github_url']); ?>" target="_blank" class="btn btn-outline btn-sm">GitHub</a>
                <?php endif; ?>
                <?php if ($p['live_url']): ?>
                <a href="<?php echo htmlspecialchars($p['live_url']); ?>" target="_blank" class="btn btn-primary btn-sm">Live Demo →</a>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</section>

<?php include 'includes/footer.php'; ?>
