// Mobile hamburger menu
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobileMenu');
if (hamburger && mobileMenu) {
    hamburger.addEventListener('click', () => {
        mobileMenu.classList.toggle('open');
    });
}

// Animate skill bars on scroll
function animateSkillBars() {
    const bars = document.querySelectorAll('.skill-fill');
    bars.forEach(bar => {
        const target = bar.getAttribute('data-width');
        if (target) bar.style.width = target + '%';
    });
}

const skillSection = document.querySelector('.skills-grid');
if (skillSection) {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) animateSkillBars();
        });
    }, { threshold: 0.2 });
    observer.observe(skillSection);
    // Set initial width to 0
    document.querySelectorAll('.skill-fill').forEach(b => b.style.width = '0');
}

// Fade-in on scroll
const fadeEls = document.querySelectorAll('.card, .skill-card');
const fadeObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, { threshold: 0.1 });

fadeEls.forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    fadeObserver.observe(el);
});

// Auto-dismiss alerts
document.querySelectorAll('.alert').forEach(alert => {
    setTimeout(() => {
        alert.style.opacity = '0';
        alert.style.transition = 'opacity 0.5s ease';
        setTimeout(() => alert.remove(), 500);
    }, 4000);
});
