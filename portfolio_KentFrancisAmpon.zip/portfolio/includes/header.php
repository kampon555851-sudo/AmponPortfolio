<?php
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' | Kent Francis Ampon Portfolio' : 'Kent Francis Ampon | IT Portfolio'; ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=DM+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="noise-overlay"></div>

    <nav class="navbar">
        <a href="index.php" class="nav-logo">
            <span class="logo-bracket">[</span>KFA<span class="logo-bracket">]</span>
        </a>
        <div class="nav-links">
            <a href="index.php" class="<?php echo $currentPage == 'index.php' ? 'active' : ''; ?>">Home</a>
            <a href="about.php" class="<?php echo $currentPage == 'about.php' ? 'active' : ''; ?>">About</a>
            <a href="projects.php" class="<?php echo $currentPage == 'projects.php' ? 'active' : ''; ?>">Projects</a>
            <a href="skills.php" class="<?php echo $currentPage == 'skills.php' ? 'active' : ''; ?>">Skills</a>
            <a href="contact.php" class="<?php echo $currentPage == 'contact.php' ? 'active' : ''; ?>">Contact</a>
        </div>
        <button class="hamburger" id="hamburger">&#9776;</button>
    </nav>

    <div class="mobile-menu" id="mobileMenu">
        <a href="index.php">Home</a>
        <a href="about.php">About</a>
        <a href="projects.php">Projects</a>
        <a href="skills.php">Skills</a>
        <a href="contact.php">Contact</a>
    </div>

    <main class="main-content">
