    </main>

    <footer class="footer">
        <div class="footer-inner">
            <span class="footer-logo"><span class="logo-bracket">[</span>KFA<span class="logo-bracket">]</span></span>
            <p class="footer-copy">&copy; <?php echo date('Y'); ?> Kent Francis Ampon. All rights reserved.</p>
            <div class="footer-links">
                <a href="https://github.com/" target="_blank">GitHub</a>
                <a href="https://linkedin.com/" target="_blank">LinkedIn</a>
                <a href="contact.php">Contact</a>
            </div>
        </div>
    </footer>

    <script src="assets/js/main.js"></script>
</body>
</html>
