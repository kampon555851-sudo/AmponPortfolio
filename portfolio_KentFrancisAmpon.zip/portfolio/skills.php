<?php
require_once 'includes/db.php';
$pageTitle = 'Skills';
include 'includes/header.php';

$conn = getConnection();
$result = $conn->query("SELECT * FROM skills ORDER BY category, proficiency DESC");
$all_skills = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
$conn->close();

$grouped = [];
foreach ($all_skills as $skill) {
    $grouped[$skill['category']][] = $skill;
}

if (empty($grouped)) {
    $grouped = [
        'Web Development' => [
            ['name' => 'PHP', 'proficiency' => 82],
            ['name' => 'MySQL', 'proficiency' => 78],
            ['name' => 'HTML5', 'proficiency' => 90],
            ['name' => 'CSS3', 'proficiency' => 85],
            ['name' => 'JavaScript', 'proficiency' => 70],
        ],
        'Graphic Design' => [
            ['name' => 'Figma', 'proficiency' => 80],
            ['name' => 'Canva', 'proficiency' => 90],
            ['name' => 'Adobe Photoshop', 'proficiency' => 72],
            ['name' => 'UI/UX Design', 'proficiency' => 68],
        ],
        'Tools & DevOps' => [
            ['name' => 'Git & GitHub', 'proficiency' => 75],
            ['name' => 'XAMPP / Apache', 'proficiency' => 80],
            ['name' => 'VS Code', 'proficiency' => 92],
        ],
        'Concepts' => [
            ['name' => 'CRUD Operations', 'proficiency' => 88],
            ['name' => 'MVC Architecture', 'proficiency' => 70],
            ['name' => 'Responsive Design', 'proficiency' => 82],
        ],
    ];
}
?>

<section class="section">
    <div class="section-label">// Technical & Creative Skills</div>
    <h2 class="section-title">What I Work With</h2>
    <div class="section-divider"></div>

    <div class="skills-grid">
        <?php foreach ($grouped as $category => $skills): ?>
        <div class="skill-card">
            <div class="skill-category"><?php echo htmlspecialchars($category); ?></div>
            <?php foreach ($skills as $skill): ?>
            <div class="skill-item">
                <div class="skill-label">
                    <span><?php echo htmlspecialchars($skill['name']); ?></span>
                    <span><?php echo $skill['proficiency']; ?>%</span>
                </div>
                <div class="skill-bar">
                    <div class="skill-fill" data-width="<?php echo $skill['proficiency']; ?>"></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endforeach; ?>
    </div>
</section>

<section class="section" style="padding-top:0;">
    <div class="section-label">// Technologies & Tools</div>
    <h2 class="section-title">Tech Stack</h2>
    <div class="section-divider"></div>

    <div style="display:flex; flex-wrap:wrap; gap:0.75rem;">
        <?php
        $techs = ['PHP 8', 'MySQL', 'HTML5', 'CSS3', 'JavaScript ES6', 'Figma', 'Canva',
                  'Adobe Photoshop', 'Git', 'GitHub', 'XAMPP', 'Bootstrap', 'VS Code',
                  'Responsive Design', 'UI/UX', 'MVC Pattern', 'REST API', 'Laravel (Learning)'];
        foreach ($techs as $t): ?>
        <span style="font-family:var(--mono); font-size:0.78rem; letter-spacing:0.08em;
                     border:1px solid var(--border); color:var(--text-secondary);
                     padding:0.5rem 1rem; border-radius:2px; transition:all 0.2s; cursor:default;"
              onmouseover="this.style.borderColor='var(--accent)'; this.style.color='var(--accent)';"
              onmouseout="this.style.borderColor='var(--border)'; this.style.color='var(--text-secondary)';">
            <?php echo htmlspecialchars($t); ?>
        </span>
        <?php endforeach; ?>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
