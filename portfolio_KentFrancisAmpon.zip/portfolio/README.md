# Kent Francis M. Ampon — Portfolio Management System

**Course:** IT9a/L – Professional Track for IT 3  
**Project:** Web-Based Portfolio Management System  
**Admin Login:** `admin` / `admin123`

---

## Project Structure

```
portfolio/
├── index.php              # Homepage with hero + featured projects
├── about.php              # About me page
├── projects.php           # Public projects listing (with category filter)
├── skills.php             # Skills & tech stack page
├── contact.php            # Contact form (saves to DB)
├── database.sql           # Database setup + sample data
│
├── includes/
│   ├── db.php             # Database connection config
│   ├── auth.php           # Session / login helper
│   ├── header.php         # Shared navigation header
│   └── footer.php         # Shared footer
│
├── assets/
│   ├── css/style.css      # Full dark-theme stylesheet
│   └── js/main.js         # Hamburger menu, animations
│
└── admin/
    ├── login.php          # Admin login page
    ├── logout.php         # Logout handler
    ├── dashboard.php      # Admin dashboard with stats
    ├── projects.php       # CRUD: Add / Edit / Delete projects
    ├── skills.php         # CRUD: Add / Edit / Delete skills
    └── messages.php       # View / Delete contact messages
```

---

## Setup Instructions

1. **Import the database**
   - Open phpMyAdmin (via XAMPP)
   - Create a new database called `portfolio_db`
   - Import `database.sql`

2. **Configure DB connection** (if needed)
   - Open `includes/db.php`
   - Update `DB_USER` and `DB_PASS` to match your XAMPP settings

3. **Run the project**
   - Place the folder in `htdocs/`
   - Visit `http://localhost/portfolio/`

4. **Admin Panel**
   - Visit `http://localhost/portfolio/admin/login.php`
   - Username: `admin` | Password: `admin123`

---

## Features

- **Public Portfolio** — Home, About, Projects, Skills, Contact pages
- **Admin Authentication** — Session-based login/logout
- **Projects CRUD** — Add, edit, delete projects with category & tech stack
- **Skills CRUD** — Add, edit, delete skills with proficiency levels
- **Contact Form** — Saves messages to DB; admin can view/delete them
- **Category Filter** — Filter projects by category on the projects page
- **Responsive Design** — Mobile-friendly with hamburger navigation

---

## Technologies Used

| Layer     | Technology             |
|-----------|------------------------|
| Backend   | PHP 8                  |
| Database  | MySQL                  |
| Frontend  | HTML5, CSS3, JavaScript |
| Design    | Figma (UI mockup)      |
| Server    | Apache (XAMPP)         |
| Version Control | Git & GitHub    |
