<?php
require_once 'includes/db.php';
$pageTitle = 'Home';
include 'includes/header.php';

// Fetch featured projects (latest 3)
$conn = getConnection();
$result = $conn->query("SELECT * FROM projects ORDER BY created_at DESC LIMIT 3");
$featured = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
$conn->close();
?>

<!-- HERO -->
<section class="hero">
    <div class="hero-inner">
        <div class="hero-tag">
            <span class="dot"></span>
            Available for opportunities
        </div>
        <h1 class="hero-name">
            Kent Francis<br><span class="accent">Ampon.</span>
        </h1>
        <p class="hero-title">IT Student · Web Developer &amp; Graphic Designer</p>
        <p class="hero-desc">
            I craft dynamic, database-driven web applications and visual designs that communicate clearly and look great.
            Passionate about combining clean backend logic with compelling front-end experiences.
        </p>
        <div class="hero-actions">
            <a href="projects.php" class="btn btn-primary">View Projects →</a>
            <a href="contact.php" class="btn btn-outline">Get in Touch</a>
        </div>
    </div>
</section>

<!-- FEATURED PROJECTS -->
<section class="section">
    <div class="section-label">// Featured Work</div>
    <h2 class="section-title">Recent Projects</h2>
    <div class="section-divider"></div>

    <?php if (empty($featured)): ?>
    <div class="empty-state">
        <div class="empty-icon">📁</div>
        <p>No projects yet. <a href="admin/projects.php" style="color:var(--accent)">Add your first project →</a></p>
    </div>
    <?php else: ?>
    <div class="card-grid">
        <?php foreach ($featured as $project): ?>
        <div class="card">
            <span class="card-tag"><?php echo htmlspecialchars($project['category']); ?></span>
            <h3 class="card-title"><?php echo htmlspecialchars($project['title']); ?></h3>
            <p class="card-desc"><?php echo htmlspecialchars(substr($project['description'], 0, 120)) . (strlen($project['description']) > 120 ? '...' : ''); ?></p>
            <div class="card-actions">
                <?php if ($project['github_url']): ?>
                <a href="<?php echo htmlspecialchars($project['github_url']); ?>" target="_blank" class="btn btn-outline btn-sm">GitHub</a>
                <?php endif; ?>
                <?php if ($project['live_url']): ?>
                <a href="<?php echo htmlspecialchars($project['live_url']); ?>" target="_blank" class="btn btn-primary btn-sm">Live →</a>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <div style="margin-top:2.5rem; text-align:center;">
        <a href="projects.php" class="btn btn-outline">View All Projects →</a>
    </div>
    <?php endif; ?>
</section>

<!-- QUICK STATS -->
<section class="section" style="padding-top:0;">
    <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:1rem; border:1px solid var(--border); border-radius:4px; overflow:hidden;">
        <div style="padding:2rem; text-align:center; border-right:1px solid var(--border);">
            <div style="font-family:var(--mono); font-size:2rem; color:var(--accent); font-weight:700;">PHP</div>
            <div style="font-size:0.8rem; color:var(--text-muted); margin-top:0.3rem; font-family:var(--mono); letter-spacing:0.08em;">Backend</div>
        </div>
        <div style="padding:2rem; text-align:center; border-right:1px solid var(--border);">
            <div style="font-family:var(--mono); font-size:2rem; color:var(--accent); font-weight:700;">MySQL</div>
            <div style="font-size:0.8rem; color:var(--text-muted); margin-top:0.3rem; font-family:var(--mono); letter-spacing:0.08em;">Database</div>
        </div>
        <div style="padding:2rem; text-align:center; border-right:1px solid var(--border);">
            <div style="font-family:var(--mono); font-size:2rem; color:var(--accent); font-weight:700;">HTML/CSS</div>
            <div style="font-size:0.8rem; color:var(--text-muted); margin-top:0.3rem; font-family:var(--mono); letter-spacing:0.08em;">Frontend</div>
        </div>
        <div style="padding:2rem; text-align:center;">
            <div style="font-family:var(--mono); font-size:2rem; color:var(--accent); font-weight:700;">Figma</div>
            <div style="font-size:0.8rem; color:var(--text-muted); margin-top:0.3rem; font-family:var(--mono); letter-spacing:0.08em;">Design</div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
