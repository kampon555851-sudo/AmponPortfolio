<?php
require_once 'includes/db.php';
$pageTitle = 'Contact';

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if (empty($name) || empty($email) || empty($message)) {
        $error = 'Please fill in all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        $conn = getConnection();
        $stmt = $conn->prepare("INSERT INTO messages (name, email, subject, message) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $subject, $message);
        if ($stmt->execute()) {
            $success = 'Your message has been sent! I\'ll get back to you soon.';
        } else {
            $error = 'Something went wrong. Please try again.';
        }
        $stmt->close();
        $conn->close();
    }
}

include 'includes/header.php';
?>

<section class="section">
    <div class="section-label">// Get In Touch</div>
    <h2 class="section-title">Contact Me</h2>
    <div class="section-divider"></div>

    <?php if ($success): ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
    <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <div class="contact-grid">
        <!-- Info Panel -->
        <div class="contact-info">
            <h3>Let's Connect</h3>
            <p style="color:var(--text-secondary); font-size:0.9rem; margin-bottom:2rem; line-height:1.8;">
                Whether you have a project in mind, a question, or just want to say hello —
                I'd love to hear from you. Fill out the form and I'll respond as soon as possible.
            </p>

            <div class="contact-item">
                <span class="contact-icon">📧</span>
                <div class="contact-item-text">
                    <label>Email</label>
                    <span>kent.ampon@email.com</span>
                </div>
            </div>
            <div class="contact-item">
                <span class="contact-icon">📍</span>
                <div class="contact-item-text">
                    <label>Location</label>
                    <span>Philippines</span>
                </div>
            </div>
            <div class="contact-item">
                <span class="contact-icon">🎓</span>
                <div class="contact-item-text">
                    <label>Course</label>
                    <span>IT9a/L – Professional Track for IT 3</span>
                </div>
            </div>
            <div class="contact-item">
                <span class="contact-icon">💻</span>
                <div class="contact-item-text">
                    <label>GitHub</label>
                    <span>github.com/kentampon</span>
                </div>
            </div>
        </div>

        <!-- Contact Form -->
        <div>
            <form method="POST" action="contact.php">
                <div class="form-group">
                    <label for="name">Name *</label>
                    <input type="text" id="name" name="name" placeholder="Your full name"
                           value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">Email *</label>
                    <input type="email" id="email" name="email" placeholder="your@email.com"
                           value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" required>
                </div>
                <div class="form-group">
                    <label for="subject">Subject</label>
                    <input type="text" id="subject" name="subject" placeholder="What's this about?"
                           value="<?php echo isset($_POST['subject']) ? htmlspecialchars($_POST['subject']) : ''; ?>">
                </div>
                <div class="form-group">
                    <label for="message">Message *</label>
                    <textarea id="message" name="message" placeholder="Your message here..." required><?php echo isset($_POST['message']) ? htmlspecialchars($_POST['message']) : ''; ?></textarea>
                </div>
                <button type="submit" class="btn btn-primary" style="width:100%; justify-content:center;">
                    Send Message →
                </button>
            </form>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
