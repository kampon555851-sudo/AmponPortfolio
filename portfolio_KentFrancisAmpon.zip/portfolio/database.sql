-- ============================================
-- Portfolio Database Setup
-- Name: Kent Francis M. Ampon
-- Course: IT9a/L - Professional Track for IT 3
-- ============================================

CREATE DATABASE IF NOT EXISTS portfolio_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE portfolio_db;

-- ============================================
-- TABLE: projects
-- ============================================
CREATE TABLE IF NOT EXISTS projects (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    title       VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    category    VARCHAR(100) DEFAULT 'General',
    tech_stack  VARCHAR(255),
    github_url  VARCHAR(500),
    live_url    VARCHAR(500),
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TABLE: skills
-- ============================================
CREATE TABLE IF NOT EXISTS skills (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    category    VARCHAR(100) NOT NULL,
    proficiency INT DEFAULT 50 CHECK (proficiency BETWEEN 0 AND 100),
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- TABLE: messages (from contact form)
-- ============================================
CREATE TABLE IF NOT EXISTS messages (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(100) NOT NULL,
    email      VARCHAR(150) NOT NULL,
    subject    VARCHAR(255),
    message    TEXT NOT NULL,
    is_read    TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- SAMPLE DATA: Projects
-- ============================================
INSERT INTO projects (title, description, category, tech_stack, github_url, live_url) VALUES
(
    'Web-Based Portfolio Management System',
    'A dynamic, database-driven portfolio website built with PHP and MySQL. Features full CRUD operations for managing projects and skills, admin authentication, and a public-facing portfolio view with a contact form.',
    'Web Development',
    'PHP, MySQL, HTML5, CSS3, JavaScript',
    'https://github.com/kentampon/portfolio-system',
    NULL
),
(
    'Student Information System',
    'A school management web app that allows administrators to manage student records, enrollment, and grades. Built with PHP and MySQL following MVC principles.',
    'Web Development',
    'PHP, MySQL, Bootstrap, HTML, CSS',
    'https://github.com/kentampon/student-info-system',
    NULL
),
(
    'Event Poster Series',
    'A collection of promotional posters designed for school events using Figma and Adobe Photoshop. Focused on strong typography, color theory, and visual hierarchy.',
    'Graphic Design',
    'Figma, Adobe Photoshop, Canva',
    NULL,
    NULL
),
(
    'Responsive Company Landing Page',
    'A fully responsive landing page for a fictitious IT company. Designed the UI mockup in Figma first, then implemented it using HTML, CSS, and vanilla JavaScript.',
    'Web Development',
    'HTML5, CSS3, JavaScript, Figma',
    'https://github.com/kentampon/landing-page',
    NULL
),
(
    'Brand Identity Design',
    'Created a complete brand identity package including logo, color palette, typography guide, and social media templates for a local small business using Figma and Canva.',
    'Graphic Design',
    'Figma, Canva, Adobe Photoshop',
    NULL,
    NULL
);

-- ============================================
-- SAMPLE DATA: Skills
-- ============================================
INSERT INTO skills (name, category, proficiency) VALUES
('PHP', 'Web Development', 82),
('MySQL', 'Web Development', 78),
('HTML5', 'Web Development', 90),
('CSS3', 'Web Development', 85),
('JavaScript', 'Web Development', 70),
('Figma', 'Graphic Design', 80),
('Canva', 'Graphic Design', 92),
('Adobe Photoshop', 'Graphic Design', 72),
('UI/UX Design', 'Graphic Design', 68),
('Git & GitHub', 'Tools & DevOps', 75),
('XAMPP / Apache', 'Tools & DevOps', 80),
('VS Code', 'Tools & DevOps', 92),
('CRUD Operations', 'Concepts', 88),
('MVC Architecture', 'Concepts', 70),
('Responsive Design', 'Concepts', 82);
