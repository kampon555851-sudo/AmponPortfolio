<?php
require_once '../includes/auth.php';

if (isLoggedIn()) {
    header("Location: dashboard.php");
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Default credentials: admin / admin123 (change in production!)
    if ($username === 'admin' && $password === 'admin123') {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_user'] = $username;
        header("Location: dashboard.php");
        exit();
    } else {
        $error = 'Invalid username or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login | Kent Francis Ampon Portfolio</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="noise-overlay"></div>

<div class="login-wrap">
    <div class="login-box">
        <h1><span class="logo-bracket">[</span>AR<span class="logo-bracket">]</span> Admin</h1>
        <p>Sign in to manage your portfolio</p>

        <?php if ($error): ?>
        <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="POST" action="login.php">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" placeholder="admin" required autofocus>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="••••••••" required>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%; justify-content:center; margin-top:0.5rem;">
                Login →
            </button>
        </form>

        <p style="margin-top:1.5rem; font-size:0.75rem; color:var(--text-muted); text-align:center;">
            Default: admin / admin123
        </p>

        <p style="margin-top:0.75rem; text-align:center;">
            <a href="../index.php" style="font-family:var(--mono); font-size:0.72rem; color:var(--text-muted); text-decoration:none;">← Back to Portfolio</a>
        </p>
    </div>
</div>

<script src="../assets/js/main.js"></script>
</body>
</html>
