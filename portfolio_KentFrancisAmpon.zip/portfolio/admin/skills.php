<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
requireLogin();

$conn = getConnection();
$action = $_GET['action'] ?? 'list';
$error = '';

if ($action === 'delete' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $conn->query("DELETE FROM skills WHERE id = $id");
    header("Location: skills.php?deleted=1");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id          = (int)($_POST['id'] ?? 0);
    $name        = trim($_POST['name'] ?? '');
    $category    = trim($_POST['category'] ?? '');
    $proficiency = min(100, max(0, (int)($_POST['proficiency'] ?? 50)));

    if (empty($name) || empty($category)) {
        $error = 'Name and category are required.';
    } else {
        if ($id > 0) {
            $stmt = $conn->prepare("UPDATE skills SET name=?, category=?, proficiency=? WHERE id=?");
            $stmt->bind_param("ssii", $name, $category, $proficiency, $id);
        } else {
            $stmt = $conn->prepare("INSERT INTO skills (name, category, proficiency) VALUES (?,?,?)");
            $stmt->bind_param("ssi", $name, $category, $proficiency);
        }
        if ($stmt->execute()) {
            header("Location: skills.php?saved=1");
            exit();
        } else {
            $error = 'Database error.';
        }
    }
}

$edit = null;
if ($action === 'edit' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $res = $conn->query("SELECT * FROM skills WHERE id = $id");
    $edit = $res ? $res->fetch_assoc() : null;
}

$skills = $conn->query("SELECT * FROM skills ORDER BY category, name")->fetch_all(MYSQLI_ASSOC) ?? [];
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Skills | Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="noise-overlay"></div>
<nav class="navbar">
    <a href="../index.php" class="nav-logo"><span class="logo-bracket">[</span>AR<span class="logo-bracket">]</span> <span style="font-size:0.7rem; color:var(--accent)">ADMIN</span></a>
    <div class="nav-links">
        <a href="dashboard.php">Dashboard</a>
        <a href="projects.php">Projects</a>
        <a href="skills.php" class="active">Skills</a>
        <a href="messages.php">Messages</a>
        <a href="logout.php">Logout</a>
    </div>
</nav>

<div style="padding-top:64px;">
<div class="admin-wrap">
    <div class="admin-header">
        <h1>Manage Skills</h1>
        <?php if ($action === 'list'): ?>
        <a href="skills.php?action=add" class="btn btn-primary">+ Add Skill</a>
        <?php else: ?>
        <a href="skills.php" class="btn btn-outline btn-sm">← Back to List</a>
        <?php endif; ?>
    </div>

    <?php if (isset($_GET['saved'])): ?><div class="alert alert-success">Skill saved!</div><?php endif; ?>
    <?php if (isset($_GET['deleted'])): ?><div class="alert alert-success">Skill deleted.</div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <?php if ($action === 'add' || $action === 'edit'): ?>
    <div style="max-width:500px;">
        <form method="POST" action="skills.php">
            <?php if ($edit): ?>
            <input type="hidden" name="id" value="<?php echo $edit['id']; ?>">
            <?php endif; ?>
            <div class="form-group">
                <label>Skill Name *</label>
                <input type="text" name="name" value="<?php echo htmlspecialchars($edit['name'] ?? ''); ?>" required>
            </div>
            <div class="form-group">
                <label>Category *</label>
                <input type="text" name="category" placeholder="e.g. Backend, Frontend, Tools" value="<?php echo htmlspecialchars($edit['category'] ?? ''); ?>" required>
            </div>
            <div class="form-group">
                <label>Proficiency: <span id="profLabel"><?php echo $edit['proficiency'] ?? 70; ?></span>%</label>
                <input type="range" name="proficiency" min="0" max="100" value="<?php echo $edit['proficiency'] ?? 70; ?>"
                       oninput="document.getElementById('profLabel').textContent = this.value"
                       style="width:100%; accent-color:var(--accent);">
            </div>
            <button type="submit" class="btn btn-primary">Save Skill →</button>
        </form>
    </div>

    <?php else: ?>
    <?php if (empty($skills)): ?>
    <div class="empty-state"><div class="empty-icon">🛠️</div><p>No skills yet.</p></div>
    <?php else: ?>
    <table class="admin-table">
        <thead>
            <tr><th>#</th><th>Skill</th><th>Category</th><th>Proficiency</th><th>Actions</th></tr>
        </thead>
        <tbody>
            <?php foreach ($skills as $i => $s): ?>
            <tr>
                <td style="font-family:var(--mono); color:var(--text-muted); font-size:0.75rem;"><?php echo $i + 1; ?></td>
                <td><?php echo htmlspecialchars($s['name']); ?></td>
                <td><span class="badge badge-yellow"><?php echo htmlspecialchars($s['category']); ?></span></td>
                <td>
                    <div style="display:flex; align-items:center; gap:0.75rem;">
                        <div style="flex:1; height:3px; background:var(--border); border-radius:2px;">
                            <div style="width:<?php echo $s['proficiency']; ?>%; height:100%; background:var(--accent); border-radius:2px;"></div>
                        </div>
                        <span style="font-family:var(--mono); font-size:0.72rem; color:var(--text-muted); width:35px;"><?php echo $s['proficiency']; ?>%</span>
                    </div>
                </td>
                <td>
                    <div style="display:flex; gap:0.5rem;">
                        <a href="skills.php?action=edit&id=<?php echo $s['id']; ?>" class="btn btn-outline btn-sm">Edit</a>
                        <a href="skills.php?action=delete&id=<?php echo $s['id']; ?>" class="btn btn-danger"
                           onclick="return confirm('Delete this skill?')">Delete</a>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
    <?php endif; ?>
</div>
</div>
<script src="../assets/js/main.js"></script>
</body>
</html>
