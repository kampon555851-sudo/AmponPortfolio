<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
requireLogin();

$conn = getConnection();
$projectCount = $conn->query("SELECT COUNT(*) as c FROM projects")->fetch_assoc()['c'] ?? 0;
$messageCount = $conn->query("SELECT COUNT(*) as c FROM messages")->fetch_assoc()['c'] ?? 0;
$unreadCount  = $conn->query("SELECT COUNT(*) as c FROM messages WHERE is_read = 0")->fetch_assoc()['c'] ?? 0;
$skillCount   = $conn->query("SELECT COUNT(*) as c FROM skills")->fetch_assoc()['c'] ?? 0;

$recentMsgs = $conn->query("SELECT * FROM messages ORDER BY created_at DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC) ?? [];
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="noise-overlay"></div>

<nav class="navbar">
    <a href="../index.php" class="nav-logo"><span class="logo-bracket">[</span>AR<span class="logo-bracket">]</span> <span style="font-size:0.7rem; color:var(--accent)">ADMIN</span></a>
    <div class="nav-links">
        <a href="dashboard.php" class="active">Dashboard</a>
        <a href="projects.php">Projects</a>
        <a href="skills.php">Skills</a>
        <a href="messages.php">Messages <?php if ($unreadCount > 0): ?><span class="badge badge-red" style="margin-left:4px"><?php echo $unreadCount; ?></span><?php endif; ?></a>
        <a href="logout.php">Logout</a>
    </div>
</nav>

<div style="padding-top:64px;">
<div class="admin-wrap">
    <div class="admin-header">
        <h1>Dashboard</h1>
        <a href="../index.php" class="btn btn-outline btn-sm">← View Portfolio</a>
    </div>

    <!-- Stats -->
    <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:1rem; margin-bottom:2.5rem;">
        <div class="card" style="text-align:center;">
            <div style="font-family:var(--mono); font-size:2.5rem; color:var(--accent); font-weight:700;"><?php echo $projectCount; ?></div>
            <div style="font-size:0.8rem; color:var(--text-muted); font-family:var(--mono); letter-spacing:0.1em; margin-top:0.3rem;">PROJECTS</div>
        </div>
        <div class="card" style="text-align:center;">
            <div style="font-family:var(--mono); font-size:2.5rem; color:var(--accent); font-weight:700;"><?php echo $skillCount; ?></div>
            <div style="font-size:0.8rem; color:var(--text-muted); font-family:var(--mono); letter-spacing:0.1em; margin-top:0.3rem;">SKILLS</div>
        </div>
        <div class="card" style="text-align:center;">
            <div style="font-family:var(--mono); font-size:2.5rem; color:var(--accent); font-weight:700;"><?php echo $messageCount; ?></div>
            <div style="font-size:0.8rem; color:var(--text-muted); font-family:var(--mono); letter-spacing:0.1em; margin-top:0.3rem;">MESSAGES</div>
        </div>
        <div class="card" style="text-align:center;">
            <div style="font-family:var(--mono); font-size:2.5rem; color:var(--red); font-weight:700;"><?php echo $unreadCount; ?></div>
            <div style="font-size:0.8rem; color:var(--text-muted); font-family:var(--mono); letter-spacing:0.1em; margin-top:0.3rem;">UNREAD</div>
        </div>
    </div>

    <!-- Quick Actions -->
    <div style="display:flex; gap:0.75rem; flex-wrap:wrap; margin-bottom:2.5rem;">
        <a href="projects.php?action=add" class="btn btn-primary">+ Add Project</a>
        <a href="skills.php?action=add" class="btn btn-outline">+ Add Skill</a>
        <a href="messages.php" class="btn btn-outline">View Messages</a>
    </div>

    <!-- Recent Messages -->
    <div>
        <div style="font-family:var(--mono); font-size:0.72rem; color:var(--accent); letter-spacing:0.15em; text-transform:uppercase; margin-bottom:1rem;">Recent Messages</div>
        <?php if (empty($recentMsgs)): ?>
        <div class="empty-state"><p>No messages yet.</p></div>
        <?php else: ?>
        <table class="admin-table">
            <thead>
                <tr>
                    <th>From</th>
                    <th>Subject</th>
                    <th>Date</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($recentMsgs as $msg): ?>
                <tr>
                    <td><?php echo htmlspecialchars($msg['name']); ?></td>
                    <td><?php echo htmlspecialchars($msg['subject'] ?: '(No subject)'); ?></td>
                    <td style="font-family:var(--mono); font-size:0.75rem;"><?php echo date('M d, Y', strtotime($msg['created_at'])); ?></td>
                    <td><?php echo $msg['is_read'] ? '<span class="badge badge-green">Read</span>' : '<span class="badge badge-red">Unread</span>'; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>
</div>

<script src="../assets/js/main.js"></script>
</body>
</html>
