<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
requireLogin();

$conn = getConnection();
$action = $_GET['action'] ?? 'list';

if ($action === 'delete' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $conn->query("DELETE FROM messages WHERE id = $id");
    header("Location: messages.php?deleted=1");
    exit();
}

// Mark as read and show
$view = null;
if ($action === 'view' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $conn->query("UPDATE messages SET is_read = 1 WHERE id = $id");
    $res = $conn->query("SELECT * FROM messages WHERE id = $id");
    $view = $res ? $res->fetch_assoc() : null;
}

$messages = $conn->query("SELECT * FROM messages ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC) ?? [];
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Messages | Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="noise-overlay"></div>
<nav class="navbar">
    <a href="../index.php" class="nav-logo"><span class="logo-bracket">[</span>AR<span class="logo-bracket">]</span> <span style="font-size:0.7rem; color:var(--accent)">ADMIN</span></a>
    <div class="nav-links">
        <a href="dashboard.php">Dashboard</a>
        <a href="projects.php">Projects</a>
        <a href="skills.php">Skills</a>
        <a href="messages.php" class="active">Messages</a>
        <a href="logout.php">Logout</a>
    </div>
</nav>

<div style="padding-top:64px;">
<div class="admin-wrap">
    <div class="admin-header">
        <h1>Messages</h1>
        <?php if ($view): ?>
        <a href="messages.php" class="btn btn-outline btn-sm">← Back to List</a>
        <?php endif; ?>
    </div>

    <?php if (isset($_GET['deleted'])): ?><div class="alert alert-success">Message deleted.</div><?php endif; ?>

    <?php if ($view): ?>
    <!-- Message Detail -->
    <div style="max-width:700px;">
        <div class="card">
            <div style="display:flex; justify-content:space-between; align-items:start; margin-bottom:1.5rem;">
                <div>
                    <h2 style="font-family:var(--mono); font-size:1rem; margin-bottom:0.25rem;">
                        <?php echo htmlspecialchars($view['subject'] ?: '(No subject)'); ?>
                    </h2>
                    <div style="font-size:0.8rem; color:var(--text-muted);">
                        From: <strong style="color:var(--text-secondary)"><?php echo htmlspecialchars($view['name']); ?></strong>
                        &lt;<?php echo htmlspecialchars($view['email']); ?>&gt;
                    </div>
                    <div style="font-family:var(--mono); font-size:0.7rem; color:var(--text-muted); margin-top:0.3rem;">
                        <?php echo date('F d, Y \a\t g:i A', strtotime($view['created_at'])); ?>
                    </div>
                </div>
                <span class="badge badge-green">Read</span>
            </div>
            <div style="color:var(--text-secondary); line-height:1.8; white-space:pre-wrap; border-top:1px solid var(--border); padding-top:1.25rem;">
                <?php echo nl2br(htmlspecialchars($view['message'])); ?>
            </div>
            <div style="margin-top:1.5rem; display:flex; gap:0.75rem;">
                <a href="mailto:<?php echo htmlspecialchars($view['email']); ?>" class="btn btn-primary btn-sm">Reply via Email</a>
                <a href="messages.php?action=delete&id=<?php echo $view['id']; ?>" class="btn btn-danger"
                   onclick="return confirm('Delete this message?')">Delete</a>
            </div>
        </div>
    </div>

    <?php else: ?>
    <!-- Messages Table -->
    <?php if (empty($messages)): ?>
    <div class="empty-state"><div class="empty-icon">✉️</div><p>No messages yet.</p></div>
    <?php else: ?>
    <table class="admin-table">
        <thead>
            <tr><th>Status</th><th>From</th><th>Subject</th><th>Date</th><th>Actions</th></tr>
        </thead>
        <tbody>
            <?php foreach ($messages as $m): ?>
            <tr style="<?php echo !$m['is_read'] ? 'background:rgba(232,255,107,0.03)' : ''; ?>">
                <td><?php echo $m['is_read'] ? '<span class="badge badge-green">Read</span>' : '<span class="badge badge-red">Unread</span>'; ?></td>
                <td>
                    <div style="font-weight:<?php echo !$m['is_read'] ? '600' : '400'; ?>">
                        <?php echo htmlspecialchars($m['name']); ?>
                    </div>
                    <div style="font-size:0.75rem; color:var(--text-muted);"><?php echo htmlspecialchars($m['email']); ?></div>
                </td>
                <td><?php echo htmlspecialchars($m['subject'] ?: '(No subject)'); ?></td>
                <td style="font-family:var(--mono); font-size:0.72rem;"><?php echo date('M d, Y', strtotime($m['created_at'])); ?></td>
                <td>
                    <div style="display:flex; gap:0.5rem;">
                        <a href="messages.php?action=view&id=<?php echo $m['id']; ?>" class="btn btn-outline btn-sm">View</a>
                        <a href="messages.php?action=delete&id=<?php echo $m['id']; ?>" class="btn btn-danger"
                           onclick="return confirm('Delete this message?')">Delete</a>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
    <?php endif; ?>
</div>
</div>
<script src="../assets/js/main.js"></script>
</body>
</html>
