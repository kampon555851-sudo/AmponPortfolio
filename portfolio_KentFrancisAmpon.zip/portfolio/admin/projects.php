<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
requireLogin();

$conn = getConnection();
$action = $_GET['action'] ?? 'list';
$msg = '';
$error = '';

// Handle DELETE
if ($action === 'delete' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $conn->query("DELETE FROM projects WHERE id = $id");
    header("Location: projects.php?deleted=1");
    exit();
}

// Handle CREATE / UPDATE
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id          = (int)($_POST['id'] ?? 0);
    $title       = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $category    = trim($_POST['category'] ?? '');
    $tech_stack  = trim($_POST['tech_stack'] ?? '');
    $github_url  = trim($_POST['github_url'] ?? '');
    $live_url    = trim($_POST['live_url'] ?? '');

    if (empty($title) || empty($description)) {
        $error = 'Title and description are required.';
    } else {
        if ($id > 0) {
            $stmt = $conn->prepare("UPDATE projects SET title=?, description=?, category=?, tech_stack=?, github_url=?, live_url=? WHERE id=?");
            $stmt->bind_param("ssssssi", $title, $description, $category, $tech_stack, $github_url, $live_url, $id);
        } else {
            $stmt = $conn->prepare("INSERT INTO projects (title, description, category, tech_stack, github_url, live_url) VALUES (?,?,?,?,?,?)");
            $stmt->bind_param("ssssss", $title, $description, $category, $tech_stack, $github_url, $live_url);
        }
        if ($stmt->execute()) {
            header("Location: projects.php?saved=1");
            exit();
        } else {
            $error = 'Database error: ' . $conn->error;
        }
    }
}

// Load edit data
$edit = null;
if ($action === 'edit' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $res = $conn->query("SELECT * FROM projects WHERE id = $id");
    $edit = $res ? $res->fetch_assoc() : null;
}

// Load all projects
$projects = $conn->query("SELECT * FROM projects ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC) ?? [];
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Projects | Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="noise-overlay"></div>
<nav class="navbar">
    <a href="../index.php" class="nav-logo"><span class="logo-bracket">[</span>AR<span class="logo-bracket">]</span> <span style="font-size:0.7rem; color:var(--accent)">ADMIN</span></a>
    <div class="nav-links">
        <a href="dashboard.php">Dashboard</a>
        <a href="projects.php" class="active">Projects</a>
        <a href="skills.php">Skills</a>
        <a href="messages.php">Messages</a>
        <a href="logout.php">Logout</a>
    </div>
</nav>

<div style="padding-top:64px;">
<div class="admin-wrap">
    <div class="admin-header">
        <h1>Manage Projects</h1>
        <?php if ($action === 'list'): ?>
        <a href="projects.php?action=add" class="btn btn-primary">+ Add Project</a>
        <?php else: ?>
        <a href="projects.php" class="btn btn-outline btn-sm">← Back to List</a>
        <?php endif; ?>
    </div>

    <?php if (isset($_GET['saved'])): ?><div class="alert alert-success">Project saved successfully!</div><?php endif; ?>
    <?php if (isset($_GET['deleted'])): ?><div class="alert alert-success">Project deleted.</div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <?php if ($action === 'add' || $action === 'edit'): ?>
    <!-- Form -->
    <div style="max-width:700px;">
        <div style="font-family:var(--mono); font-size:0.72rem; color:var(--accent); letter-spacing:0.15em; text-transform:uppercase; margin-bottom:1.5rem;">
            <?php echo $action === 'edit' ? '// Edit Project' : '// New Project'; ?>
        </div>
        <form method="POST" action="projects.php">
            <?php if ($edit): ?>
            <input type="hidden" name="id" value="<?php echo $edit['id']; ?>">
            <?php endif; ?>
            <div class="form-group">
                <label>Project Title *</label>
                <input type="text" name="title" value="<?php echo htmlspecialchars($edit['title'] ?? ''); ?>" required>
            </div>
            <div class="form-group">
                <label>Description *</label>
                <textarea name="description" rows="4" required><?php echo htmlspecialchars($edit['description'] ?? ''); ?></textarea>
            </div>
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem;">
                <div class="form-group">
                    <label>Category</label>
                    <input type="text" name="category" placeholder="e.g. Web Dev, IT, Design" value="<?php echo htmlspecialchars($edit['category'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label>Tech Stack (comma-separated)</label>
                    <input type="text" name="tech_stack" placeholder="PHP, MySQL, HTML" value="<?php echo htmlspecialchars($edit['tech_stack'] ?? ''); ?>">
                </div>
            </div>
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem;">
                <div class="form-group">
                    <label>GitHub URL</label>
                    <input type="url" name="github_url" placeholder="https://github.com/..." value="<?php echo htmlspecialchars($edit['github_url'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label>Live URL</label>
                    <input type="url" name="live_url" placeholder="https://..." value="<?php echo htmlspecialchars($edit['live_url'] ?? ''); ?>">
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Save Project →</button>
        </form>
    </div>

    <?php else: ?>
    <!-- Projects Table -->
    <?php if (empty($projects)): ?>
    <div class="empty-state"><div class="empty-icon">📁</div><p>No projects yet.</p></div>
    <?php else: ?>
    <table class="admin-table">
        <thead>
            <tr>
                <th>#</th>
                <th>Title</th>
                <th>Category</th>
                <th>Tech Stack</th>
                <th>Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($projects as $i => $p): ?>
            <tr>
                <td style="font-family:var(--mono); color:var(--text-muted); font-size:0.75rem;"><?php echo $i + 1; ?></td>
                <td><?php echo htmlspecialchars($p['title']); ?></td>
                <td><span class="badge badge-yellow"><?php echo htmlspecialchars($p['category']); ?></span></td>
                <td style="font-size:0.8rem; color:var(--text-muted);"><?php echo htmlspecialchars(substr($p['tech_stack'], 0, 40)); ?></td>
                <td style="font-family:var(--mono); font-size:0.72rem;"><?php echo date('M d, Y', strtotime($p['created_at'])); ?></td>
                <td>
                    <div style="display:flex; gap:0.5rem;">
                        <a href="projects.php?action=edit&id=<?php echo $p['id']; ?>" class="btn btn-outline btn-sm">Edit</a>
                        <a href="projects.php?action=delete&id=<?php echo $p['id']; ?>" class="btn btn-danger"
                           onclick="return confirm('Delete this project?')">Delete</a>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
    <?php endif; ?>
</div>
</div>
<script src="../assets/js/main.js"></script>
</body>
</html>
